const Interview = require('../models/Interview');
const Recruiter = require('../models/Recruiter');
const Candidate = require('../models/Candidate');
const Notification = require('../models/Notification');
const { getPaginationParams, buildPaginationResponse, applyPagination } = require('../utils/pagination');

// @desc    Get all interviews
// @route   GET /api/v1/interviews
// @access  Private
exports.getInterviews = async (req, res, next) => {
  try {
    const { page, limit, skip } = getPaginationParams(req);
    let query = {};
    
    // Filter by user role
    if (req.user.role === 'candidate') {
      const candidate = await Candidate.findOne({ user_id: req.user.id });
      if (candidate) {
        query.candidate_id = candidate._id;
      }
    } else if (req.user.role === 'recruiter') {
      const recruiter = await Recruiter.findOne({ user_id: req.user.id });
      if (recruiter) {
        query.recruiter_id = recruiter._id;
      }
    }
    
    // Additional filters
    if (req.query.status) {
      query.interview_status = req.query.status;
    }
    
    const interviewsQuery = Interview.find(query)
      .populate('feedback')
      .sort('interview_date');
    
    const interviews = await applyPagination(interviewsQuery, page, limit, skip);
    const total = await Interview.countDocuments(query);
    
    res.status(200).json(buildPaginationResponse(interviews, total, page, limit));
  } catch (error) {
    next(error);
  }
};

// @desc    Get single interview
// @route   GET /api/v1/interviews/:id
// @access  Private
exports.getInterview = async (req, res, next) => {
  try {
    const interview = await Interview.findById(req.params.id)
      .populate('feedback');
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // Check if user has access to this interview
    if (req.user.role === 'candidate') {
      const candidate = await Candidate.findOne({ user_id: req.user.id });
      if (interview.candidate_id._id.toString() !== candidate._id.toString()) {
        return res.status(401).json({
          success: false,
          message: 'Not authorized to view this interview'
        });
      }
    } else if (req.user.role === 'recruiter') {
      const recruiter = await Recruiter.findOne({ user_id: req.user.id });
      if (interview.recruiter_id._id.toString() !== recruiter._id.toString()) {
        return res.status(401).json({
          success: false,
          message: 'Not authorized to view this interview'
        });
      }
    }
    
    res.status(200).json({
      success: true,
      data: interview
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create interview
// @route   POST /api/v1/interviews
// @access  Private/Recruiter
exports.createInterview = async (req, res, next) => {
  try {
    // Get recruiter
    const recruiter = await Recruiter.findOne({ user_id: req.user.id });
    
    if (!recruiter) {
      return res.status(400).json({
        success: false,
        message: 'User is not a recruiter'
      });
    }
    
    req.body.recruiter_id = recruiter._id;
    
    const interview = await Interview.create(req.body);
    
    // Notify candidate
    const fullInterview = await Interview.findById(interview._id);
    if (fullInterview) {
      const candidateUserId = fullInterview.candidate_id.user_id._id || fullInterview.candidate_id.user_id;
      
      await Notification.create({
        user_id: candidateUserId,
        title: 'New Interview Scheduled',
        message: `You have an interview scheduled for ${fullInterview.application_id.job_id.title} at ${fullInterview.recruiter_id.company_name}`,
        notification_type: 'interview_reminder',
        related_entity_type: 'Interview',
        related_entity_id: interview._id,
        action_url: `/candidate/interviews`
      });
    }
    
    res.status(201).json({
      success: true,
      data: interview
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update interview
// @route   PUT /api/v1/interviews/:id
// @access  Private/Recruiter
exports.updateInterview = async (req, res, next) => {
  try {
    let interview = await Interview.findById(req.params.id);
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // Get recruiter
    const recruiter = await Recruiter.findOne({ user_id: req.user.id });
    
    // Make sure user is interview owner
    if (interview.recruiter_id.toString() !== recruiter._id.toString() && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to update this interview'
      });
    }

    const oldStatus = interview.status;
    const oldDate = interview.interview_date ? interview.interview_date.toISOString() : null;
    const oldTime = interview.interview_time;
    
    interview = await Interview.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    // Notify candidate if status or time changed
    const fullInterview = await Interview.findById(interview._id);
    if (fullInterview) {
       const candidateUserId = fullInterview.candidate_id.user_id._id || fullInterview.candidate_id.user_id;
       const companyName = fullInterview.recruiter_id.company_name;
       const jobTitle = fullInterview.application_id.job_id.title;
       
       if (req.body.status && req.body.status !== oldStatus) {
         let title = 'Interview Status Update';
         let message = `Your interview for ${jobTitle} at ${companyName} has been updated to ${req.body.status}.`;
         
         if (req.body.status === 'cancelled') {
           title = 'Interview Cancelled';
           message = `Your interview for ${jobTitle} at ${companyName} has been cancelled.`;
         } else if (req.body.status === 'completed') {
           title = 'Interview Completed';
           message = `Your interview for ${jobTitle} at ${companyName} has been marked as completed.`;
         }
         
         await Notification.create({
            user_id: candidateUserId,
            title,
            message,
            notification_type: 'interview_reminder', // or system
            related_entity_type: 'Interview',
            related_entity_id: interview._id,
            action_url: `/candidate/interviews`
         });
       } else if (
         (req.body.interview_date && new Date(req.body.interview_date).toISOString() !== oldDate) || 
         (req.body.interview_time && req.body.interview_time !== oldTime)
       ) {
         await Notification.create({
            user_id: candidateUserId,
            title: 'Interview Rescheduled',
            message: `Your interview for ${jobTitle} at ${companyName} has been rescheduled to ${fullInterview.interview_time} on ${new Date(fullInterview.interview_date).toLocaleDateString()}.`,
            notification_type: 'interview_reminder',
            related_entity_type: 'Interview',
            related_entity_id: interview._id,
            action_url: `/candidate/interviews`
         });
       }
    }
    
    res.status(200).json({
      success: true,
      data: interview
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Confirm interview attendance (Candidate)
// @route   PUT /api/v1/interviews/:id/confirm
// @access  Private/Candidate
exports.confirmInterview = async (req, res, next) => {
  try {
    const { message } = req.body;
    const interview = await Interview.findById(req.params.id);

    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }

    // Verify user is the candidate for this interview
    const candidate = await Candidate.findOne({ user_id: req.user.id });
    if (!candidate || interview.candidate_id.toString() !== candidate._id.toString()) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to confirm this interview'
      });
    }

    if (interview.status !== 'scheduled') {
      return res.status(400).json({
        success: false,
        message: 'Can only confirm scheduled interviews'
      });
    }

    interview.candidate_confirmation = {
      is_confirmed: true,
      message: message || '',
      confirmed_at: new Date()
    };

    await interview.save();

    // Notify recruiter
    const fullInterview = await Interview.findById(interview._id);
    if (fullInterview) {
      const recruiterUserId = fullInterview.recruiter_id.user_id._id || fullInterview.recruiter_id.user_id;
      const candidateName = fullInterview.candidate_id.user_id.first_name + ' ' + fullInterview.candidate_id.user_id.last_name;
      
      await Notification.create({
        user_id: recruiterUserId,
        title: 'Interview Confirmed',
        message: `${candidateName} has confirmed the interview for ${fullInterview.application_id.job_id.title}`,
        notification_type: 'system',
        related_entity_type: 'Interview',
        related_entity_id: interview._id,
        action_url: `/recruiter/interviews`
      });
    }

    res.status(200).json({
      success: true,
      data: interview
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete interview
// @route   DELETE /api/v1/interviews/:id
// @access  Private/Recruiter
exports.deleteInterview = async (req, res, next) => {
  try {
    const interview = await Interview.findById(req.params.id);
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // Get recruiter
    const recruiter = await Recruiter.findOne({ user_id: req.user.id });
    console.log('Recruiter:', recruiter._id , "---", interview.recruiter_id._id);
    // Make sure user is interview owner
    if (interview.recruiter_id._id.toString() !== recruiter._id.toString() && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to delete this interview'
      });
    }
    
    await interview.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};
